STUDENT ENROLLMENT PROJECT
==========================

This ZIP contains four separate HTML pages and their matching CSS files:

1. 01-enrollment-form.html + .css
   Blank student enrollment form.
2. 02-enrollment-validation.html + .css
   Same form with Student ID and EMail fields highlighted red, matching the second reference.
3. 03-student-record.html + .css
   Student record table using the sample information shown in the reference.
4. 04-student-summary.html + .css
   Student summary report/dashboard.

HOW TO OPEN
-----------
1. Extract/unzip this folder.
2. Open any .html file in a web browser (Chrome, Edge, Firefox).
3. Keep each HTML file beside its matching CSS file so the design loads correctly.

NOTE
----
The pages are made with HTML and CSS only, as requested. The form layout is a visual example;
it does not save or submit student records to a database.
